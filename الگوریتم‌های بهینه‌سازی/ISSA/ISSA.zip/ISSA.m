%      Improved Salp Swarm Algorithm (ISSA) source code version 1.0.0
%..........................................................................
% Authored and programmed by: Dorian Sidea
% 
% e-mail:   doriansidea@gmail.com 
%
%..........................................................................
% The algorithm is developed as part of the paper:
%   Andrei Tudose, Dorian Sidea, Irina Picioroaga, Nicolae Anton, Constantin Bulac
%    Increasing Distributed Generation Hosting Capacity Based on a 
%    Sequential Optimization Approach Using an Improved Salp Swarm Algorithm
%  (Currently under review for publishing)
%
%       This research was supported by the project AOSR TEAMS, grant number 
%       301/14.04.2022, funded by the Academy of Romanian Scientists.
% 
%..........................................................................
%  In order to use the ISSA you can define the objective function in a
%  separate file and provide a handle to it
%
% The ISSA input parameters are:
% fobj  - Handle to the objective function (@fobj)
% Nvars - Number of variables
% Ntot  - Total number of salps
% LoB   - Row vector containing the lower bounds for the variables
% UpB   - Row vector containing the upper bounds for the variables
% tMax  - Maximum number of iterations
%
% The ISSA output parameters are:
% FoodFit - The best objective function value found by ISSA
% FoodPos - The variables values corresponding to the optimal solution
% Convergence_curve - The FoodFit value at each iteration
%..........................................................................

function [FoodFit,FoodPos,ConvCurve]=ISSA(Ntot,tMax,LoB,UpB,Nvars,fobj)
%% Set parameters
pFoll = 0.2;
pPion = 0.3;
%% Initialization
ConvCurve = zeros(1,tMax);
FoodPos = zeros(1,Nvars);
SalpFit = zeros(Ntot,1);



%% Initialize the positions of salps


SalpPos = rand(Ntot,Nvars).*(UpB-LoB)+LoB;



for i=1:Ntot
    SalpFit(i,1)=fobj(SalpPos(i,:));
end

[SalpFit,sortIndex]=sort(SalpFit);
SalpPos = SalpPos(sortIndex,:);
FoodPos = SalpPos(1,:);
FoodFit = SalpFit(1);
ConvCurve(1) = FoodFit;


%% Main loop
t = 2; % First iteration was the initialization
while t <= tMax
    % Compute c1 parameter
    c1 = 2 * exp(-(4 * t / tMax) ^ 2);
    % Compute   Nexp (exploring salps number),
    
    

    

    for i = 1 : Ntot
        if i == 1 % update the Leader Salp  -- Eq. (19) from the paper
            r1 = rand(1,Nvars); % Random numbers
            r2 = rand(1,Nvars); % Random numbers
            r3 = rand(1,Nvars); % Random numbers

            if r3 < 0.5 % Decide the sign + or -
                SalpPos(i,:) = FoodPos + r1 .* ((UpB - LoB) .* r2 + LoB);
            else
                SalpPos(i,:) = FoodPos - r1 .* ((UpB - LoB) .* r2 + LoB);
            end

        else % update the other Salps (Followers, Rogues and Pioneers)
            r = rand ; % Random number to select the salp type (F,R or P)
            if r < pFoll % Follower Salp -- Eq. (27) from the paper
                r1 = rand(1,Nvars) ;
                SalpPos(i,:)=(SalpPos(i-1,:).* r1 + SalpPos(i,:) .*(1-r1) ); %  

            else
                r = rand ; % Random number to select the salp type (R or P)
                if r < pPion % Pioneer Salp
                    r1 = rand;
                    if r1 < 0.25 % Eq. (22) from the paper
                        r2= rand(1,Nvars) - 0.5 ;
                        r3 = rand(1,Nvars) ;
                        SalpPos(i,:) = SalpPos(randi(Ntot),:) +  r2 .* r3 .* ((UpB-LoB)+LoB);
                    elseif r1 <0.5 % Eq. (23) from the paper
                        r2 = rand(1,Nvars) ;
                        SalpPos(i,:) = SalpPos(randi(Ntot),:) .* r2 + SalpPos(randi(Ntot),:) .* (1-r2);
                    elseif r1 < 0.7 % Eq. (24) from the paper
                        r2 = rand(1,Nvars) ;
                        SalpPos(i,:) = r2 .* ((UpB-LoB)+LoB);
                    else            % Eq. (25) from the paper
                        SalpPos(i,:) = UpB + LoB - SalpPos(i,:) ;
                    end
                else % Rogue Salp -- Eq. (26) from the paper
                    r2= rand(1,Nvars) - 0.5;
                    r3 = rand(1,Nvars);
                    SalpPos(i,:) = FoodPos+ r2 .* (FoodPos.* r3 - (1-r3) .* SalpPos(i,:));
                end
            end
        end
        
        % Enforce Boundaries by replacing the value that violates a limit
        % with the violated limit
        Fupb=find(SalpPos(i,:)>UpB);
        Flob=find(SalpPos(i,:)<LoB);
        SalpPos(i,Fupb) = UpB(1,Fupb);
        SalpPos(i,Flob) = LoB(1,Flob);
        
        % Compute the salp fitnes
        SalpFit(i,1) = fobj(SalpPos(i,:));
        
        % If necessary update the Food Position and Fitness
        if SalpFit(i,1) < FoodFit
            FoodPos = SalpPos(i,:);
            FoodFit = SalpFit(i,1);
        end
    end % for i = 1 : Ntot
    
    % Sort the salps
    [SalpFit,sortIndex] = sort(SalpFit);
    SalpPos = SalpPos(sortIndex,:);
    
    % Update the converge curve
    ConvCurve(t)=FoodFit;
    
    if 0% mod(l,10) == 0
        display([t,FoodFit]);
    end
    % Increment iteration
    t = t + 1;
end % while t <= tMax
end % function